import threading
import json
import time
import uuid
import logging
import logging.handlers
import logaugment
from pyrus.models.requests import CreateTaskRequest, TaskCommentRequest
from pyrus.models.entities import FormField
from . import objects_plus
from . import client_plus


logger = logging.getLogger(__name__)


class PyrusHandler(logging.Handler):
    """
    Custom handler for logging to Pyrus task
    """
    pyrus_client = None
    log_task_id = None

    def __init__(self, pyrus_client, log_task_id):
        self.pyrus_client = pyrus_client
        self.log_task_id = log_task_id
        logging.Handler.__init__(self)

    def emit(self, record):
        """
        Emits a record - Formats the record and send it to the specified task.
        """
        if self.log_task_id is None:
            print("No log task id!")
            return
        try:
            self.pyrus_client.comment_task(self.log_task_id, TaskCommentRequest(text=self.format(record)))
        except Exception:
            self.handleError(record)


def create_pyrus_email_formatter():
    return logging.Formatter('%(bot_name)s-%(task_id)d|%(session_id)s|%(retry)s|'
                             '%(asctime)s|%(filename)s[LINE:%(lineno)d]#'
                             '%(levelname)s | %(message)s',
                             datefmt='%Y-%m-%d %H:%M:%S')


def create_pyrus_email_airflow_formatter():
    return logging.Formatter(
        '%(bot_name)s-Airflow|%(session_id)s|%(retry)s|'
        '%(asctime)s|%(filename)s[LINE:%(lineno)d]#'
        '%(levelname)s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )


def create_console_formatter():
    return logging.Formatter('%(bot_name)s-%(task_id)d|%(session_id)s|%(retry)s|'
                             '%(asctime)s|%(filename)s[LINE:%(lineno)d]#'
                             '%(levelname)s | %(message)s',
                             datefmt='%Y-%m-%d %H:%M:%S')


def create_console_airflow_formatter():
    return logging.Formatter(
        '%(bot_name)s-AirFlow|%(session_id)s|%(retry)s|'
        '%(asctime)s|%(filename)s[LINE:%(lineno)d]#'
        '%(levelname)s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )


class Bot:
    configuration = None  # Configuration of bot in Pyrus
    pyrus_client = None

    # Properties of current bot call
    body = None
    full_task = None  # JSON with full task details
    task_id = None
    task = None  # Pyrus API TaskWithComments entity
    session_id = None
    retry = None
    test = False

    # Bot profile info
    user_id = None
    first_name = None
    last_name = None

    # Logging info
    log_task_id = None
    log_form_id = None
    log_task_field_id = None
    log_email = None

    def __init__(self):
        self.pyrus_client = client_plus.MyPyrus()

    @property
    def full_name(self):
        if self.first_name is None and self.last_name is None:
            return "NoNameBot"
        else:
            return (self.first_name if self.first_name is not None else "") + \
                   (" " if (self.first_name and self.last_name) else "") + \
                   (self.last_name if self.last_name is not None else "")

    def init_from_webhook(self, body, retry, session_id):
        """
        Initializing from a webhook call
        :param body:
        :param retry:
        :param session_id:
        :return:
        """
        self.configuration = json.loads(body['bot_settings'])
        self.pyrus_client.get_host(self.configuration)
        self.task_id = body['task_id']
        self.first_name = self.configuration.get("BOT_NAME")
        self._pre_init(retry, session_id, False)
        self.pyrus_client.initialize_from_token(body['access_token'])
        if self.first_name is None:
            self.whoami()
        self.full_task = body['task']
        # Converting python dictionary to Pyrus API TaskWithComments object
        self.task = objects_plus.TaskWithCommentsPlus(**self.full_task)
        self.user_id = body['user_id']
        self._logging_init()

    def init_from_test(self, filename, task_id=0, config_bot_filename='bot_config.json'):
        """
        Initialising from a test call
        :param filename: file with bot's credentials
        :param task_id: task_id to apply bot to
        :param config_bot_filename: file with bot configuration
        :return:
        """
        # Filling bot properties
        with open(config_bot_filename, encoding="utf8") as f:
            self.configuration = json.load(f)
        self.task_id = task_id
        self.first_name = self.configuration.get("BOT_NAME")
        self._pre_init("Manual", str(uuid.uuid4().fields[-1])[:5], True)
        self.pyrus_client.initialize_from_file(filename)
        if self.task_id != 0:
            logger.debug("Getting task details for bot task")
            task_response = self.pyrus_client.get_task(task_id)
            self.full_task = task_response.original_response['task']
            self.task = task_response.task
            self._logging_init()

    def init_from_airflow(self, filename, config_bot_filename):
        """
        Initialising from a test call
        :param filename: file with bot's credentials
        :param config_bot_filename: file with bot configuration
        :return:
        """
        # Filling bot properties
        with open(config_bot_filename, encoding="utf8") as f:
            self.configuration = json.load(f)
        self.first_name = self.configuration.get("BOT_NAME")
        self._pre_init_airflow("Manual", str(uuid.uuid4().fields[-1])[:5], True)
        self.pyrus_client.initialize_from_file(filename)
        logger.debug("Getting task details for bot task")
        self._email_airflow_logging_init()

    def whoami(self):
        logger.debug("Obtaining bot name")
        profile = self.pyrus_client.get_profile()
        logger.debug(f"Bot profile received: {profile}")
        self.first_name = profile.get("first_name", "")
        self.last_name = profile.get("last_name", "")

    def _pre_init(self, retry, session_id, test):
        self.retry = retry
        self.session_id = session_id
        self.test = test
        self._console_logging_init()

    def _pre_init_airflow(self, retry, session_id, test):
        self.retry = retry
        self.session_id = session_id
        self.test = test
        self._console_airflow_logging_init()

    def _logging_init(self):
        self.logging = self.configuration.get('LOGGING')
        if self.logging:
            self._pyrus_logging_init()
            self._email_logging_init()
            # Updating handlers parameters
            for handler in logging.getLogger().handlers:
                self._set_handler_parameters(handler)

    def _console_logging_init(self):
        self.logger = logging.getLogger()
        self.logger.name = self.full_name
        if self.logger.hasHandlers():
            self.logger.handlers.clear()
        self.logger.addHandler(self._create_stream_handler())

    def _console_airflow_logging_init(self):
        self.logger = logging.getLogger()
        self.logger.name = self.full_name
        if self.logger.hasHandlers():
            self.logger.handlers.clear()
        self.logger.addHandler(self._create_stream_airflow_handler())

    def _pyrus_logging_init(self):
        self.log_form_id = self.configuration.get('LOG_FORM_ID')
        self.log_global_task_id = self.configuration.get('GLOBAL_LOG_TASK_ID')
        self.log_task_field_id = self.configuration.get('LOG_TASK_FIELD_ID')
        self.logger.addHandler(self._create_global_pyrus_handler())
        comments = len(self.task.comments)
        if self.task.id is not None:
            if not self.pyrus_client.get_linked_task(self.task.linked_task_ids, self.log_form_id) and comments == 1:
                create_flag = self.configuration.get('CREATE_LOG_TASK')
                if create_flag:
                    self._create_log_init_task()
                else:
                    time.sleep(5)
                    task = self.pyrus_client.get_task(self.task.id).task
                    self.task.linked_task_ids = task.linked_task_ids
                    self._init_log_task()
            else:
                self._init_log_task()
        self.logger.addHandler(self._create_pyrus_handler())

    def _email_logging_init(self):
        self.log_email = self.configuration.get("LOG_EMAIL", None)
        if self.log_email is not None:
            self.logger.addHandler(self._create_email_handler())

    def _email_airflow_logging_init(self):
        self.log_email = self.configuration.get("LOG_EMAIL", None)
        if self.log_email is not None:
            self.logger.addHandler(self._create_email_airflow_handler())

    def _init_log_task(self):
        logger.debug("Initialising logging to Pyrus")
        if self.task.linked_task_ids is not None:
            for task_id in self.task.linked_task_ids:
                task = self.pyrus_client.get_task(task_id).task
                if task.form_id is not None and task.form_id == self.log_form_id:
                    self.log_task_id = task.id
                    logger.debug(f"Log task {self.log_task_id} found for {self.task.id}")
        if self.log_task_id is not None:
            text = f'Log task found for #{self.task.id}'
            self.pyrus_client.comment_task_plus(self.log_task_id, **{'text': text})

    def _create_log_init_task(self):
        log_task = self.pyrus_client.create_task(
            CreateTaskRequest(
                form_id=self.log_form_id,
                fields=[FormField(id=self.log_task_field_id, value=self.task.id)]
            )
        )
        if log_task.error is not None:
            self.log_task_id = None
            logger.error(f"Error during creating log task - {log_task.error}")
        else:
            self.log_task_id = log_task.task.id
            logger.debug(f"Log task created {self.log_task_id} for task {self.task.id}")
            self.pyrus_client.comment_task(
                self.log_task_id,
                TaskCommentRequest(text=f"Log task created for #{self.task.id}")
            )
            logger.debug(f"To log task {self.log_task_id} added a comment linking to {self.task.id}")

    def _create_pyrus_handler(self):
        ph = PyrusHandler(self.pyrus_client, self.log_task_id)
        ph.setLevel(logging.INFO)
        ph.setFormatter(create_pyrus_email_formatter())
        return ph

    def _create_global_pyrus_handler(self):
        phg = PyrusHandler(self.pyrus_client, self.log_global_task_id)
        phg.setLevel(logging.ERROR)
        phg.setFormatter(create_pyrus_email_formatter())
        return phg

    def _create_stream_handler(self):
        sh = logging.StreamHandler()
        sh.setLevel(logging.DEBUG)
        sh.setFormatter(create_console_formatter())
        self._set_handler_parameters(sh)
        return sh

    def _create_stream_airflow_handler(self):
        sh = logging.StreamHandler()
        sh.setLevel(logging.DEBUG)
        sh.setFormatter(create_console_airflow_formatter())
        self._set_handler_parameters(sh)
        return sh

    def _create_email_handler(self):
        eh = logging.handlers.SMTPHandler(mailhost=('smtp.gmail.com', 587),
                                          fromaddr='pyrusapi@gmail.com',
                                          toaddrs=[self.log_email],
                                          subject=f'Log error for bot working in {self.task.id}',
                                          credentials=('pyrusapi@gmail.com', 'rxlfohsldpwufsom'),
                                          secure=())
        eh.setLevel(logging.ERROR)
        eh.setFormatter(create_pyrus_email_formatter())
        return eh

    def _create_email_airflow_handler(self):
        eh = logging.handlers.SMTPHandler(mailhost=('smtp.gmail.com', 587),
                                          fromaddr='pyrusapi@gmail.com',
                                          toaddrs=[self.log_email],
                                          subject=f'Log error for bot working in Airflow',
                                          credentials=('pyrusapi@gmail.com', 'rxlfohsldpwufsom'),
                                          secure=())
        eh.setLevel(logging.ERROR)
        eh.setFormatter(create_pyrus_email_airflow_formatter())
        return eh

    def _set_handler_parameters(self, handler):
        logaugment.set(handler, bot_name=self.full_name, session_id=f"ID:{self.session_id}",
                       retry=self.retry, task_id=self.task_id)


def start_in_thread(fn, *args, **kwargs):
    """Run function fn with given args and kwargs in a newly created thread."""
    t = threading.Thread(group=None, target=fn, args=args, kwargs=kwargs)
    t.start()
