from pyrus.models.customhandlers import FormFieldHandler


class NewFormHandler(FormFieldHandler):
    def flatten(self, obj, data):
        if obj.id:
            data['id'] = obj.id
        if obj.name:
            data['name'] = obj.name

        # ignore readonly fields
        if obj.type in ['step', 'status', 'note', 'author', 'project', 'creation_date']:
            return data

        if obj.value is not None:
            data['value'] = self._get_flatten_value(obj.type, obj.value)
        return data