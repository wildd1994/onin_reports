import logging
from pyrustools import *
logging.getLogger(__name__).addHandler(logging.NullHandler())
