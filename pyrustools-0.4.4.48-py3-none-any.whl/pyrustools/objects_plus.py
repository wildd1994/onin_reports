import itertools
from pyrus.models import entities, responses
from . import object_methods
from . import handlers


class TaskCommentPlus(entities.TaskComment):
    """
    New attribute: edited_comment_id
        edit_comment_id (:obj:`int`): Edited comment id
    """
    edit_comment_id = None
    parent_comment = None  # Initialised from TaskWithCommentsPlus
    formatted_text = None

    def __init__(self, **kwargs):
        if 'edit_comment_id' in kwargs:
            self.edit_comment_id = kwargs['edit_comment_id']
        super(TaskCommentPlus, self).__init__(**kwargs)
        self.formatted_text = kwargs.get('formatted_text')


class TaskWithCommentsPlus(entities.Task):
    """
    Using new TaskCommentPlus entity for comments
    """
    comments = None
    flat_fields_static = None
    form_template = None
    formatted_text = None

    def __init__(self, **kwargs):
        super(TaskWithCommentsPlus, self).__init__(**kwargs)
        if 'fields' in kwargs:
            self.fields = []
            for field in kwargs['fields']:
                self.fields.append(FormFieldPlus(**field))
        if 'comments' in kwargs:
            self.comments = []
            for comment in kwargs['comments']:
                self.comments.append(TaskCommentPlus(**comment))
        # Sorting comments by id
        if self.comments is not None:
            self.comments = list(sorted(self.comments, key=lambda c: c.id))
            for comment in self.comments:
                if comment.edit_comment_id is not None:
                    comment.parent_comment = object_methods.object_by_id(self.comments, comment.edit_comment_id)
        self.linked_task_ids = [] if self.linked_task_ids is None else self.linked_task_ids
        self.attachments = [] if self.attachments is None else self.attachments
        self.list_ids = [] if self.list_ids is None else self.list_ids
        self.flat_fields_static = self.flat_fields
        self.update_file_fields()
        self.formatted_text = kwargs.get('formatted_text')

    def get_files_md5(self, field_id):
        """ Returns list of md5 checksums of all files attached to this field id"""
        field_updates_nested = [c.field_updates for c in self.comments if c.field_updates is not None] if self.comments is not None else []
        field_updates = itertools.chain.from_iterable(field_updates_nested)
        values = itertools.chain.from_iterable([f.value for f in field_updates if f.id == field_id])
        return list(set([v.md5 for v in values]))

    def update_file_fields(self):
        """
            Collect all attached files in one place.
            Default behavior pyrus:
                attached files into field attachments,
                if exist field with type file whatever attached to field attachments
        """
        field_file_ids = [f.id for f in self.flat_fields_static if f.type == 'file']
        if not field_file_ids:
            return
        dict_attachments_value = {}
        if self.attachments:  # attachments смотрим в comments, там они падают с versions и root_id
            for comment in self.comments:
                if comment.attachments:
                    for attachment in comment.attachments:
                        if attachment.root_id:
                            dict_attachments_value[attachment.root_id] = attachment

        for field in self.flat_fields_static:
            if field.type == 'file' and field.value:
                new_value = []
                for value in field.value:
                    for k, v in dict_attachments_value.items():
                        if value.id == k:
                            new_value.append(v)
                if new_value:
                    field.value = new_value

    def get_fields_first_change(self, field_list):
        """ For each field id in field_list returns the number of first comment which changed this field"""
        result = {}
        if self.comments is None:
            return result
        for comment in self.comments:
            if comment.flat_field_updates is not None:
                for field in comment.flat_field_updates:
                    if field.id in field_list and result.get(field.id, None) is None:
                        if field.type == 'person' or field.value is not None:
                            result[field.id] = comment.id
        return result

    def first_change_to_step(self, step_number):
        """ Returns comment id of first comment when task changed to this field"""
        if self.comments is None:
            return None
        creation_steps = []
        if self.comments[0].approvals_added is not None:
            for approvals_list in self.comments[0].approvals_added:
                for approval in approvals_list:
                    creation_steps.append(approval.step)
        if creation_steps:
            if step_number == min(creation_steps):
                return self.comments[0].id
        for comment in self.comments:
            if comment.changed_step == step_number:
                return comment.id


class TaskResponsePlus(responses.BaseResponse):
    """
        TaskResponse

        Attributes:
            task (:obj:`TaskWithCommentsPlus`): Task
    """
    __doc__ += responses.BaseResponse.__doc__

    task = None

    def __init__(self, **kwargs):
        super(TaskResponsePlus, self).__init__(**kwargs)
        if 'task' in kwargs:
            self.task = TaskWithCommentsPlus(**kwargs['task'])


class FormResponsePlus(responses.FormResponse):
    """
        Attributes changed:
            fields (:obj:`list` of :obj:`pyrustools.FormFieldPlus`): List of form fields
    """
    __doc__ += responses.FormResponse.__doc__
    flat_fields_static = None

    @property
    def user_ids_dictionary(self):
        res = {}
        for field in self.flat_fields:
            if field.info is not None and field.info.code is not None:
                res[field.id] = field.info.code
        return res

    def __init__(self, **kwargs):
        super(FormResponsePlus, self).__init__(**kwargs)
        if 'fields' in kwargs:
            self.fields = []
            for field in kwargs['fields']:
                self.fields.append(FormFieldPlus(**field))
            self.flat_fields_static = self.flat_fields


class FormsResponsePlus(responses.BaseResponse):
    """
        FormsResponse

        Attributes:
            forms (:obj:`list` of :obj:`models.responses.FormResponse`): List of form templates
    """
    __doc__ += responses.BaseResponse.__doc__

    forms = None

    def __init__(self, **kwargs):
        if 'forms' in kwargs:
            self.forms = []
            for form in kwargs['forms']:
                self.forms.append(FormResponsePlus(**form))
        super(FormsResponsePlus, self).__init__(**kwargs)


class FormPermissions(responses.BaseResponse):
    """

    """
    __doc__ += responses.BaseResponse.__doc__

    def __init__(self, **kwargs):
        self.permissions = kwargs.get('permissions', {})
        super(FormPermissions, self).__init__(**kwargs)


@handlers.NewFormHandler.handles
class FormFieldPlus(entities.FormField):
    """
        Form field Plus

        Attributes changes:
            info (:obj:`FormFieldInfoPlus`): Additional field information with user codes and form titles
    """
    visibility_condition = None
    visible = None

    def __init__(self, **kwargs):
        super(FormFieldPlus, self).__init__(**kwargs)
        if 'value' in kwargs:
            if self.type:
                self.value = _create_field_value_plus(self.type, kwargs['value'])
            else:
                self.value = kwargs['value']
        if 'info' in kwargs:
            self.info = FormFieldInfoPlus(**kwargs['info'])
        if 'visibility_condition' in kwargs:
            self.visibility_condition = VisibilityCondition(**kwargs['visibility_condition'])


def set_value_to_field(field_id: id, value: any) -> FormFieldPlus:
    return FormFieldPlus(
        id=field_id,
        value=value
    )


class FormFieldInfoPlus(entities.FormFieldInfo):
    """
        Additional form field information - code and is_form_title added to pyrus.models.entities.FormFieldInfo

        Attributes:
            code (:obj:`str`): User or system field
            is_form_title (:obj:`boolean`): indicates if the field is added to form task name
    """

    code = None
    is_form_title = False
    multiple_choice = False

    def __init__(self, **kwargs):
        super(FormFieldInfoPlus, self).__init__(**kwargs)
        if 'code' in kwargs:
            self.code = kwargs['code']
        if 'is_form_title' in kwargs:
            self.is_form_title = kwargs['is_form_title']
        if 'multiple_choice' in kwargs:
            self.multiple_choice = kwargs['multiple_choice']
        if 'options' in kwargs:
            self.options = []
            for option in kwargs['options']:
                self.options.append(ChoiceOptionPlus(**option))
        if 'columns' in kwargs:
            self.columns = []
            for column in kwargs['columns']:
                self.columns.append(FormFieldPlus(**column))
        if 'fields' in kwargs:
            self.fields = []
            for field in kwargs['fields']:
                self.fields.append(FormFieldPlus(**field))
        if 'form_id' in kwargs:
            self.link_form_id = kwargs['form_id']


class ChoiceOptionPlus(entities.ChoiceOption):
    """
        multiple_choice options description

        Attributes changed:
            fields (:obj:`list` of :obj:`FormFieldPlus`): Child fields for the specified choice_id
    """

    def __init__(self, **kwargs):
        super(ChoiceOptionPlus, self).__init__(**kwargs)
        if 'fields' in kwargs:
            self.fields = []
            for field in kwargs['fields']:
                self.fields.append(FormFieldPlus(**field))


class VisibilityCondition:
    """
        set visibility condition for update_field_visibility
    """
    field_id = None
    condition_type = None
    value = None
    catalog_column = None
    children = None

    def __init__(self, **kwargs):
        if 'field_id' in kwargs:
            self.field_id = kwargs['field_id']
        if 'condition_type' in kwargs:
            self.condition_type = kwargs['condition_type']
        if 'value' in kwargs:
            self.value = kwargs['value']
        if 'catalog_column' in kwargs:
            self.catalog_column = kwargs['catalog_column']
        if 'children' in kwargs:
            self.children = []
            for child in kwargs['children']:
                self.children.append(VisibilityCondition(**child))


class TitlePlus(entities.Title):
    """
        Value of FormFieldPlus title

        Attributes changes:
            fields (:obj:`list` of :obj:`FormFieldPlus`): List of title child fields
    """

    def __init__(self, **kwargs):
        super(TitlePlus, self).__init__(**kwargs)
        if 'fields' in kwargs:
            self.fields = []
            for field in kwargs['fields']:
                self.fields.append(FormFieldPlus(**field))


class MultipleChoicePlus(entities.MultipleChoice):
    """
        Value of FormFieldPlus multiple_choice

        Attributes changes:
            fields (:obj:`list` of :obj:`FormFieldPlus`): List of multiple choice child fields
    """

    def __init__(self, **kwargs):
        super(MultipleChoicePlus, self).__init__(**kwargs)
        if 'fields' in kwargs:
            self.fields = []
            for field in kwargs['fields']:
                self.fields.append(FormFieldPlus(**field))


class TablePlus(entities.Table):
    """
        Value of FormFieldPlus table
        List of `models.entities.TableRowPlus`
    """
    def __init__(self, *args):
        super(TablePlus, self).__init__(*args)
        list.__init__(self)
        for value in args:
            self.append(TableRowPlus(**value))


class TableRowPlus(entities.TableRow):
    def __init__(self, **kwargs):
        super(TableRowPlus, self).__init__(**kwargs)
        if 'cells' in kwargs:
            self.cells = []
            for cell in kwargs['cells']:
                if isinstance(cell, FormFieldPlus):
                    self.cells.append(cell)
                else:
                    self.cells.append(FormFieldPlus(**cell))


def _create_field_value_plus(field_type, value):
    """
        redirect to pyrustools entities
    """
    if field_type == 'multiple_choice':
        return MultipleChoicePlus(**value)
    elif field_type == 'title':
        return TitlePlus(**value)
    elif field_type == 'table':
        return TablePlus(*value)
    else:
        return entities._create_field_value(field_type, value)
