import json
import os
import logging
import time
import urllib

from pyrus import client
from pyrus.models import requests as req
from .objects_plus import TaskResponsePlus, FormResponsePlus, TaskWithCommentsPlus, FormFieldPlus, FormsResponsePlus, FormPermissions
from .object_methods import object_by_id
from .task_copy import copy_task_fields
from .request_plus import NewTaskCommentRequest
import requests

logger = logging.getLogger(__name__)


class MyPyrus(client.PyrusAPI):

    def get_host(self, obj):
        host = obj.get('HOST')
        if host is not None:
            self._host = host
            self._base_path = '/api/v4'

    def initialize(self):
        logger.debug(f'Initializing Pyrus API client...')

        if self.login is not None and self.security_key is not None:
            result = self.auth()
            if not result.success:
                logger.error(f'Error while logging in. Error description: {result.error}')
                exit(code=result.error_code)
            else:
                logger.debug(f'Pyrus API client successfully initialized!')

    def read_login_info(self, filename):
        """
        Fills login and security key from a JSON file filename
        :param filename:
        :return:
        """
        if not os.path.isfile(filename):
            logger.error(f'Missing file with Pyrus API credentials {filename}')
        with open(filename) as f:
            try:
                obj = json.loads(f.read())
                self.login, self.security_key = obj.get('LOGIN', None), obj.get('SECRET_KEY', None)
                self.get_host(obj)
                if self.login is None or self.security_key is None:
                    logger.error(f"Credentials not found in {filename}")
            except json.decoder.JSONDecodeError:
                logger.error(f'Not a JSON file: {filename}')

    def initialize_from_file(self, config_file='credentials.json'):
        """
        Get login parameters, create pyrusAPI instance, make authorization and check for errors
        :param config_file: file, containing login and api key
        :return: pyrusAPI instance
        """
        self.read_login_info(config_file)
        self.initialize()

    def initialize_from_token(self, token):
        """
        Initializing Pyrus API using provided token (for bot usage)
        :param token: access token (received from bot call)
        :return:
        """
        self.access_token = token
        logger.debug("Pyrus API initialised from the bot token")

    def get_profile(self):
        """
        Returns user profile from Pyrus
        :return:
        """
        return self._perform_get_request(self._create_url("/profile"))

    def get_linked_tasks(self, task):
        """
        Returns dictionary { linked_task_id: linked_task }
        :param task: task to get linked tasks for
        :return: dictionary
        """
        linked_tasks = {}
        logger.debug(f"List of linked tasks for task {task.id}:{task.linked_task_ids}")
        if task.linked_task_ids is not None:
            for task_id in task.linked_task_ids:
                logger.debug(f"Getting linked task {task_id}")
                linked_task = self.get_task(task_id)
                if linked_task.task is not None:
                    linked_tasks[task_id] = linked_task
                else:
                    logger.error(f'{linked_task.error}')
        if task.parent_task_id is not None:
            logger.debug(f"Parent task {task.parent_task_id} found")
            logger.debug(f"Getting parent task {task.parent_task_id}")
            linked_task = self.get_task(task.parent_task_id)
            if linked_task.task is not None:
                linked_tasks[task.parent_task_id] = linked_task
            else:
                logger.error(f'{linked_task.error}')
        return linked_tasks

    def get_relative_tasks(self, task):
        """ Returns tasks which are either parent of child to the current"""
        relative_tasks = {k: v for (k, v) in self.get_linked_tasks(task).items() if v.task is not None and
                          (v.task.parent_task_id == task.id or v.task.id == task.parent_task_id)}
        return relative_tasks

    def get_task(self, task_id):
        """
          Get the task

          Args:
              task_id (:obj:`int`): Task id

          Returns:
              class:`pyrustools.object_plus.TaskResponsePlus` object
          """
        if not isinstance(task_id, int):
            raise Exception("task_id should be valid int")
        url = self._create_url('/tasks/{}'.format(task_id))
        response = self._perform_get_request(url)
        return TaskResponsePlus(**response)

    def get_task_with_u_codes(self):
        # Брать Task.task обновлять для него юкод и обрабатывать ошибки если есть
        # Прописать автоматическое инициализщирование юкодов
        pass

    def comment_task(self, task_id, task_comment_request):
        """
        Add task comment. This method returns a task with all comments, including the added one.
        Args:
            task_id (:obj:`int`): Task id
            task_comment_request (:obj:`models.requests.TaskCommentRequest`): Comment data.

        Returns:
            class:`pyrustools.object_plus.TaskResponsePlus` object
        """
        if not isinstance(task_id, int):
            raise Exception("task_id should be valid int")
        url = self._create_url('/tasks/{}/comments'.format(task_id))
        if not isinstance(task_comment_request, req.TaskCommentRequest):
            raise TypeError('form_register_request must be an instance '
                            'of models.requests.TaskCommentRequest')
        response = self._perform_post_request(url, task_comment_request)
        return TaskResponsePlus(**response)

    def get_form(self, form_id):
        """
        Get the form template

        Args:
            form_id (:obj:`int`): form id

        Returns:
            class:`pyrustools.object_plus.FormResponsePlus` object
        """
        if not isinstance(form_id, int):
            raise Exception("form_id should be valid int")

        url = self._create_url('/forms/{}'.format(form_id))
        response = self._perform_get_request(url)
        return FormResponsePlus(**response)

    def get_forms(self):
        """
        Get all available form templates

        Returns:
            class:`models.responses.FormsResponse` object
        """
        url = self._create_url('/forms')
        response = self._perform_get_request(url)
        return FormsResponsePlus(**response)

    def get_permissions(self, form_id):
        url = self._create_url(f'/forms/{form_id}/permissions')
        response = self._perform_get_request(url)
        return FormPermissions(**response)

    def update_task_field_info(self, task):
        """
        Updates fields in flat_fields attribute with form info field

        Args:
            task (:obj: `objects_plus.TaskWithCommentsPlus`): task to add into
        """

        if not isinstance(task, TaskWithCommentsPlus):
            raise Exception('task should be an instance of TaskWithCommentsPlus')

        if task.form_id is None:
            return
        else:
            task.form_template = self.get_form(task.form_id)
            for field in task.flat_fields_static:
                field.info = getattr(
                    object_by_id(task.form_template.flat_fields_static, field.id),
                    'info',
                    None
                )
            if len(task.comments):
                for comment in task.comments:
                    for field in comment.flat_field_updates:
                        field.info = getattr(
                            object_by_id(task.form_template.flat_fields_static, field.id),
                            'info',
                            None
                        )
            #

    def add_to_file_version(self, field_id: int, list_upload_file: list) -> dict:
        """
            Attach new file to file (add version) if it exists
        """
        form_field = FormFieldPlus(id=field_id)
        for item in list_upload_file:
            download_file = self.download_file(item[0])
            filename = download_file.filename[0].split('filename*=UTF-8')[-1].replace('\'', '')
            filename = urllib.parse.unquote(filename)
            with open(filename, 'wb') as file:
                file.write(download_file.raw_file)
            guid = self.upload_file(filename).guid
            if form_field.value:
                form_field.value.append({'guid': guid, 'root_id': item[1]})
            else:
                form_field.value = [{'guid': guid, 'root_id': item[1]}]
            os.remove(filename)
        return form_field

    def sync_tasks(self, source, destination, copy_dict):
        """Syncing fields between to tasks according to copy_dict - using task_copy.copy_task_fields"""
        
        sync_fields, dict_file_value_ids = copy_task_fields(source, destination, copy_dict)
        for field_id, list_upload_file in dict_file_value_ids.items():
            sync_fields.append(self.add_to_file_version(field_id, list_upload_file))
        task_comment_request = req.TaskCommentRequest(field_updates=sync_fields)
        # logger.debug(f"Task comment request: {self.serialize_request(task_comment_request)}")
        update = self.comment_task(destination.id, task_comment_request)
        if update.error_code is not None:
            logger.error(f"Error during syncing {update.error_code}, {update.error}")

    def get_linked_task(self, linked_task_ids, form_id):
        """
        Args: list of linked task ids, form id by which need to find tasks in the list
        return: sorted list of task from newest to oldest with updated info fields
        """
        result = []
        if linked_task_ids is not None:
            linked_task_ids.sort(reverse=True)
            for task_id in linked_task_ids:
                current_task = self.get_task(task_id).task
                if current_task.form_id == form_id:
                    self.update_task_field_info(current_task)
                    result.append(current_task)
        return result

    def update_task_visibility(self, task):
        """
            Set visibility status
        """
        for field in task.flat_fields_static:
            field.visible = self.update_field_visibility(task, field.visibility_condition)

    def comment_task_plus(self, task_id: int, **kwargs):
        """
        return None at failure add comment task or response at success comment task
        """
        request = NewTaskCommentRequest(
            field_updates=kwargs.get('field_updates'),
            text=kwargs.get('text'),
            approvals_rerequested=kwargs.get('rerequested'),
            approval_choice=kwargs.get('approval_choice'),
            channel=kwargs.get('channel'),
            attachments=kwargs.get('attachments'),
            action=kwargs.get('action'),
            approvals_added=kwargs.get('approvals_added'),
            approval_steps=kwargs.get('approval_steps'),
            participants_added=kwargs.get('participants_added'),
            reassign_to=kwargs.get('reassign_to'),
            due=kwargs.get('due'),
            due_date=kwargs.get('due_date'),
            duration=kwargs.get('duration'),
            scheduled_date=kwargs.get('scheduled_date'),
            scheduled_datetime_utc=kwargs.get('scheduled_datetime_utc'),
            cancel_schedule=kwargs.get('cancel_schedule'),
            added_list_ids=kwargs.get('added_list_ids'),
            removed_list_ids=kwargs.get('removed_list_ids'),
            approvals_removed=kwargs.get('approvals_removed'),
            subject=kwargs.get('subject'),
            participants_removed=kwargs.get('participants_removed'),
            subscribers_added=kwargs.get('subscribers_added'),
            cancel_schedule_custom=kwargs.get('cancel_schedule_custom'),
            subscribers_removed=kwargs.get('subscribers_removed')
        )

        response = self.comment_task(
            task_id=task_id,
            task_comment_request=request
        )
        if response.error is not None:
            logger.debug(f'{response.error}. Задача {task_id}')
        else:
            return response

    def create_task_plus(self, task_id, **kwargs):
        """
        Args: task id for logger - from which task create new task
        return None at failure create task or response at success create task
        """
        request = req.CreateTaskRequest(
            text=kwargs.get('text'),
            subject=kwargs.get('subject'),
            parent_task_id=kwargs.get('parent_task_id'),
            due_date=kwargs.get('due_date'),
            form_id=kwargs.get('form_id'),
            attachments=kwargs.get('attachments'),
            responsible=kwargs.get('responsible'),
            fields=kwargs.get('fields'),
            approvals=kwargs.get('approvals'),
            participants=kwargs.get('participants'),
            list_ids=kwargs.get('list_ids'),
            due=kwargs.get('due'),
            duration=kwargs.get('duration'),
            scheduled_date=kwargs.get('scheduled_date'),
            scheduled_datetime_utc=kwargs.get('scheduled_datetime_utc'),
            fill_defaults=kwargs.get('fill_defaults')
        )
        response = self.create_task(create_task_request=request)
        if response.error is not None:
            logger.debug(f'{response.error}. Задача {task_id}')
        else:
            return response

    def _auth(self):
        url = self._create_url('/auth')
        headers = {
            'User-Agent': '{}'.format(self._user_agent),
            'Content-Type': 'application/json'
        }
        params = {
            'login': self.login,
            'security_key': self.security_key
        }
        auth_response = requests.post(url, headers=headers, json=params, verify=False)
        # pylint: disable=no-member
        if auth_response.status_code == requests.codes.ok:
            response = auth_response.json()
            self.access_token = response['access_token']
        else:
            response = auth_response.json()
            self.access_token = None

        return response

    def _get_request(self, url, verify=True):
        if self._host == 'pyrus.abk-invest.ru':
            verify = False
        headers = self._create_default_headers()
        return requests.get(url, headers=headers, proxies=self.proxy, verify=verify)

    def _get_file_request(self, url, verify=True):
        if self._host == 'pyrus.abk-invest.ru':
            verify = False
        headers = self._create_default_headers()
        return requests.get(url, headers=headers, proxies=self.proxy, stream=True, verify=verify)

    def _post_request(self, url, body, verify=True):
        if self._host == 'pyrus.abk-invest.ru':
            verify = False
        headers = self._create_default_headers()
        if body:
            data = self.serialize_request(body)
        return requests.post(url, headers=headers, data=data, proxies=self.proxy, verify=verify)

    def _put_request(self, url, body, verify=True):
        if self._host == 'pyrus.abk-invest.ru':
            verify = False
        headers = self._create_default_headers()
        if body:
            data = self.serialize_request(body)
        return requests.put(url, headers=headers, data=data, proxies=self.proxy, verify=verify)

    def _post_file_request(self, url, file_path, verify=True):
        if self._host == 'pyrus.abk-invest.ru':
            verify = False
        headers = self._create_default_headers()
        del headers['Content-Type']
        if file_path:
            size = os.path.getsize(file_path)
            if size > self.MAX_FILE_SIZE_IN_BYTES:
                raise Exception("File size should not exceed {} MB".format(self.MAX_FILE_SIZE_IN_BYTES / 1024 / 1024))
            files = {'file': open(file_path, 'rb')}
        return requests.post(url, headers=headers, files=files, proxies=self.proxy, verify=False)

    def _perform_request_with_retry(self, url, method, body=None, file_path=None, get_file=False):
        if not isinstance(method, self.HTTPMethod):
            raise TypeError('method must be an instanse of HTTPMethod Enum.')

        # try auth if no access token
        if not self.access_token:
            response = self._auth()
            if not self.access_token:
                return response

        # try to call api method
        i = 0
        while True:
            if i == 5:
                logger.error(f'Не удалось получить корректное тело ответа')
                raise
            response = self._perform_request(url, method, body, file_path, get_file)
            # if 401 try auth and call method again
            if response.status_code >= 500:
                logger.debug(f'Попытка: {i+1}, Статус ответа: {response.status_code}, Ответ {response}')
                time.sleep(5)
                i += 1
                continue
            if response.status_code == 401:
                response = self._auth()
                # if failed return auth response
                if not self.access_token:
                    return response

                response = self._perform_request(url, method, body, file_path, get_file)
            break
        return self._get_response(response, get_file, body)

    def update_field_visibility(self, task, visibility_condition):
        """
            args:
                task(obj: ent.TaskWithCommentsPlus)
                visibility_condition(obj: attribute of FormFieldPlus)
            return: bool

            find visible field or not

            enum ConditionType
            {
                More = 0,
                Less = 1,
                NotFilled = 2,
                Filled = 3,
                Mask = 4,
                Equals = 5,
                MoreOrEquals = 6,
                LessOrEquals = 7,
                NotEquals = 8,
                Desc = 9,
                Or = 10,
                And = 11,
                Undefined = 12,
                True = 13,
                False = 14,
            }
        """
        if visibility_condition is None:
            return True
        else:
            if visibility_condition.field_id == 0:
                if visibility_condition.children is None:
                    return True
                else:
                    if visibility_condition.condition_type == 11:
                        for item in visibility_condition.children:
                            if not self.update_field_visibility(task, item):
                                return False
                        return True
                    if visibility_condition.condition_type == 10:
                        a = []
                        for item in visibility_condition.children:
                            a.append(self.update_field_visibility(task, item))
                        if True in a:
                            return True
            else:
                for field in task.flat_fields_static:
                    if field.id == visibility_condition.field_id:
                        if field.type == 'catalog':
                            if visibility_condition.condition_type == 2:
                                if field.value is None:
                                    return True
                            if visibility_condition.condition_type == 3:
                                if field.value:
                                    return True
                            if field.value:
                                if visibility_condition.condition_type == 5:
                                    if int(visibility_condition.value) in field.value.item_ids and field.visible:
                                        return True
                                if visibility_condition.condition_type == 8:
                                    if int(visibility_condition.value) not in field.value.item_ids and field.visible:
                                        return True
                        if field.type == 'multiple_choice':
                            if visibility_condition.condition_type == 2:
                                if field.value is None:
                                    return True
                            if visibility_condition.condition_type == 3:
                                if field.value:
                                    return True
                            if field.value:
                                if visibility_condition.condition_type == 5:
                                    if int(visibility_condition.value) in field.value.choice_ids and field.visible:
                                        return True
                                if visibility_condition.condition_type == 8:
                                    if int(visibility_condition.value) not in field.value.choice_ids and field.visible:
                                        return True
                        if field.type == 'checkmark':
                            if visibility_condition.condition_type == 2:
                                if field.value == 'unchecked':
                                    return True
                            if visibility_condition.condition_type == 3:
                                if field.value == 'checked':
                                    return True
