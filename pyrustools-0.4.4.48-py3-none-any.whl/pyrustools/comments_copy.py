from pyrus.models import requests as req


def copy_comment(task_comment, prefix='', postfix=''):
    """
    Returns a TaskCommentRequest object with the same text as original comment and files copied by ids.
    For comments which are edits to previous one returns info about original comment
    :param task_comment: Original Task Comment
    :param prefix: Line to add before comment text
    :param postfix: Line to add after comment text
    :return: TaskCommentRequest entity
    """
    if not task_comment.text and task_comment.attachments is None:
        return req.TaskCommentRequest()
    first_line = prefix + "\n" if prefix else ""
    text = task_comment.text if task_comment.text is not None else ""
    if task_comment.edit_comment_id is not None:
        text = f"Edited comments at {task_comment.parent_comment.create_date}:\n{task_comment.text}"
    last_line = ("\n" if postfix else "") + postfix
    return req.TaskCommentRequest(
        text=first_line + text + last_line,
        attachments=[str(x.id) for x in task_comment.attachments] if task_comment.attachments is not None else None
    )
