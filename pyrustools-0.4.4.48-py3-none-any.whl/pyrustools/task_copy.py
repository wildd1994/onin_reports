import logging
# noinspection PyPackageRequirements
import os

from pyrus.models import entities as ent
from .objects_plus import TaskWithCommentsPlus
from .object_methods import object_by_id

logger = logging.getLogger("pyrustools.task_copy")

# Read-only field types
PYRUS_API_RO_FIELD_TYPES = {'step', 'status', 'creation_date', 'note', 'author', 'project', 'title'}
# Read-write field types
PYRUS_API_RW_SIMPLE_FIELD_TYPES = {'text', 'money', 'number', 'date', 'time', 'checkmark',
                                   'due_date', 'due_date_time', 'email', 'phone', 'flag'}
PYRUS_API_RW_COMPLEX_FIELD_TYPES = {'catalog', 'file', 'person', 'table', 'multiple_choice'}

# All field types
PYRUS_API_FIELD_TYPES = PYRUS_API_RO_FIELD_TYPES.union(PYRUS_API_RW_SIMPLE_FIELD_TYPES,
                                                       PYRUS_API_RW_COMPLEX_FIELD_TYPES)


class TypeMismatchFieldConversionError(TypeError):
    """ Raised when cannot convert between non-convertible field types"""
    pass


class ROTypeFieldConversionError(TypeError):
    """ Raised when trying to convert read-only type"""
    pass


class CatalogMismatchError(TypeError):
    """ Raised when ids or type of catalogs are different"""
    pass


class TableCopyError(TypeError):
    """ Copying of tables is not supported"""
    pass


class ROFieldCopyError(TypeError):
    """ Copying of read-only field"""
    pass


# Explains to which type each field type can be converted
# Any simple type can be converted to text
CONVERT_TYPES_DICT = dict(text=list(PYRUS_API_RW_SIMPLE_FIELD_TYPES.union('catalog', 'multiple_choice')),
                          money=['number'],
                          number=['number'], date=['due_date'], due_date=['date'], catalog=['multiple_choice'],
                          multiple_choice=['number'])


def convert_value(source_field, field_type):
    """
    Converting pyrus-api FormField value between different types.
    If types are the same, returning source value
    If source type cannot be converted to destination type \
      raises TypeMismatchFieldConversionError
    If source type is read-only raises ROTypeFieldConversionError

    :param source_field: pyrus-api FormField object
    :param field_type: str explaining pyrus-api type
    :return: field_type field value
    """

    if not isinstance(source_field, ent.FormField):
        raise TypeError("source_field is not of type FormField")
    if field_type not in PYRUS_API_FIELD_TYPES:
        raise TypeError("field_type is not a valid string for PyrusAPI type")
    if source_field.type in PYRUS_API_RO_FIELD_TYPES:
        raise ROTypeFieldConversionError
    # No conversion needed
    if source_field.type == field_type:
        return source_field.value
    if source_field.type not in CONVERT_TYPES_DICT or CONVERT_TYPES_DICT[source_field.type] != field_type:
        raise TypeMismatchFieldConversionError

    # Now doing actual conversion
    # TODO: add conversion code


def copy_field(source_field, destination_task, copy_dict):
    """
    Copies field to another form
    :param source_field: (:obj:`pyrus.models.entities.FormField`) field to be copied (from get_task return)
    :param destination_field_template: (:obj:`pyrus.models.entities.FormField`) field template from get_form
    :return: (:obj:`pyrus.models.entities.FormField`)
    """
    if not isinstance(source_field, ent.FormField):
        raise Exception("source_field should be pyrus.models.entities.FormField")
    if source_field.type in PYRUS_API_RO_FIELD_TYPES:
        raise ROFieldCopyError
    if not isinstance(destination_task, TaskWithCommentsPlus):
        raise Exception("destination_task should be pyrustools.object_plus.TaskWithCommentsPlus")

    # Checking that we need to copy this field
    destination_field_id = copy_dict.get(source_field.id, None)
    if destination_field_id is None:
        return ent.FormField()
    destination_field_template = object_by_id(destination_task.form_template.flat_fields_static, destination_field_id)
    destination_field = object_by_id(destination_task.flat_fields_static, destination_field_id)
    dict_file_value_ids = {}
    if destination_field_template is None:
        raise Exception("destination_field_template is not found")
    if not isinstance(destination_field_template, ent.FormField):
        raise Exception("destination_field_template should be pyrus.models.entities.FormField")
    if source_field.info is None:
        raise Exception("source_field does not contain field info")
    if destination_field_template.info is None:
        raise Exception("destination_field_template does not contain field info")

    # Checking that field types are the same
    if source_field.type != destination_field_template.type:
        logger.error(f"Error while copying field with id {source_field.id} to id {destination_field_template.id}: "
                     f"different field types")

    copied_field = ent.FormField(id=destination_field_template.id, type=destination_field_template.type)
    extra_copied_field = False
    if source_field.value is None:
        if source_field.type == 'table':
            raise TableCopyError
        return copied_field, dict_file_value_ids, extra_copied_field
    elif source_field.type == 'catalog':
        if source_field.info.catalog_id != destination_field_template.info.catalog_id:
            logger.error("Can't copy catalog fields with different catalog id")
            raise CatalogMismatchError
        elif source_field.info.multiple_choice:  # Multiple choice catalog
            if not destination_field_template.info.multiple_choice:
                logger.error(f"Can't copy multiple choice catalog field {source_field.id} to single choice "
                             f"{destination_field_template.id}")
                raise CatalogMismatchError
            else:
                copied_field.value = ent.CatalogValue(item_ids=source_field.value.item_ids)
        else:  # Single choice catalog
            if destination_field_template.info.multiple_choice:
                copied_field.value = ent.CatalogValue(item_ids=[source_field.value.item_id])
            else:
                copied_field.value = ent.CatalogValue(item_id=source_field.value.item_id)
    # We copy file by ids
    elif source_field.type == 'file':
        already_attached = [x.md5 for x in destination_field.value] if destination_field.value is not None else []
        file_ids = ent.NewFile()
        for number, file in enumerate(source_field.value):
            if file.md5 not in already_attached:
                if not already_attached or number+1 > len(destination_field.value):
                    file_ids.append(str(file.id))
                else:
                    for value in destination_field.value[number:]:
                        if value.version > 1:
                            if value.md5 != file.md5:
                                if dict_file_value_ids.get(source_field.id):
                                    dict_file_value_ids[destination_field_id].append([file.id, value.root_id])
                                else:
                                    dict_file_value_ids[destination_field_id] = [[file.id, value.root_id]]
                                break
                        else:
                            if dict_file_value_ids.get(source_field.id):
                                dict_file_value_ids[destination_field_id].append([file.id, value.id])
                            else:
                                dict_file_value_ids[destination_field_id] = [[file.id, value.id]]
                            break
        if dict_file_value_ids:
            copied_field = []
        else:
            copied_field.value = file_ids
    # We copy persons by id, not emails
    elif source_field.type == 'person':
        copied_field.value = ent.Person(id=source_field.value.id)
    elif source_field.type == 'form_link':
        copied_field.value = ent.FormLink(task_ids=source_field.value.task_ids)
    # Looking for choice names with the same name in the destination field
    elif source_field.type == 'multiple_choice':
        new_choice_ids = []
        for choice_name in source_field.value.choice_names:
            for option in destination_field_template.info.options:
                if option.choice_value == choice_name:
                    new_choice_ids.append(option.choice_id)
        copied_field.value = ent.MultipleChoice(choice_ids=new_choice_ids)
    # Copying tables
    elif source_field.type == 'table':
        raise TableCopyError
        new_table = []
        for i, row in enumerate(source_field.value):
            new_cells = []
            if row.cells:
                for cell_field in row.cells:
                    copy_to_field_id = copy_dict.get(cell_field.id, None)
                    if copy_to_field_id is not None:  # We have this field in copy_dict
                        for column_field in destination_field_template.info.columns:
                            if column_field.id == copy_to_field_id:
                                new_cell = copy_field(cell_field, destination_task, copy_dict)
                                new_cells.append(new_cell)
            if new_cells:
                new_row = ent.TableRow(row_id=i, cells=new_cells)
                new_table.append(new_row)
        copied_field.value = new_table
    else:  # Simple field
        copied_field.value = source_field.value
    if source_field.info.code:  # Update name of fields in separate field
        for field in destination_task.flat_fields_static:
            if field.info:
                if field.info.code and field.info.code.find('_name') != -1 and field.info.code[2:].replace('clr_', '') != 'name':
                    if source_field.info.code == field.info.code.replace('_name', '').replace('clr_', ''):
                        extra_copied_field = ent.FormField(id=field.id, value=source_field.name)
                        break
    return [copied_field, dict_file_value_ids, extra_copied_field]


def copy_task_fields(source_task, destination_task, copy_dict):
    copied_fields = []
    new_dict_value_file_ids = {}
    for ids in copy_dict.keys():
        source_field = object_by_id(source_task.flat_fields_static, ids)
        if source_field is None:
            continue
        parent_field = object_by_id(source_task.flat_fields_static, source_field.parent_id)
        # Skipping individual copying for table fields - they will be copied as a part of a table
        if parent_field is not None and parent_field.type == 'table':
            continue
        try:
            c_field, dict_value_file_ids, extra_copied_field = copy_field(source_field, destination_task, copy_dict)
        except CatalogMismatchError:
            logger.debug(f"Field copy {source_field.id} skipped due to catalog type mismatch")
        except TableCopyError:
            logger.debug(f"Skipping copy of field {source_field.id} - table copy is not supported yet")
        except ROFieldCopyError:
            logger.debug((f"Skipping read-only field {source_field.id}"))
        else:
            copied_fields.append(c_field)
            new_dict_value_file_ids.update(dict_value_file_ids)
            if extra_copied_field:
                copied_fields.append(extra_copied_field)
    return copied_fields, new_dict_value_file_ids
