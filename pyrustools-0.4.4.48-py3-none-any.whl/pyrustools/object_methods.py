import sys
import linecache


def objects_by_key(objects, key, key_value):
    """
    Selects objects with key = value from the list
    :param objects: list of objects
    :param key: key
    :param key_value: key = key_value filter
    :return: filtered list of objects
    """
    if not objects:
        return None
    if key == 'code':
        sub_key = 'info'
        found = [
            obj for obj in objects
            if getattr(obj, sub_key, None) is not None and getattr(obj.info, key) == key_value
        ]
    else:
        found = [obj for obj in objects if getattr(obj, key, None) == key_value]
    return found if found else None


def object_by_id(objects, o_id):
    """
    Selects obj with id=id from the list

    :param objects: list of objects
    :param o_id: id to search for
    :return: object with the id=id
    """
    found = objects_by_key(objects, "id", o_id)
    return found[0] if found else None


def object_by_code(objects, u_code):
    """
    Selects obj with u_code=u_code from the list

    :param objects: list of objects
    :param u_code: u_code to search for
    :return: object with the u_code=u_code
    """
    found = objects_by_key(objects, "code", u_code)
    return found[0] if found else None


def object_by_name(objects, name):
    """
    Selects obj with name=name from the list

    :param objects: list of objects
    :param name: name to search for
    :return: object with the name=name
    """
    found = objects_by_key(objects, "name", name)
    return found[0] if found else None


def find_multiple_choice_id_by_name(name, fields, u_code):
    """
        Attributes:
            name(obj: str) - name of choice which need to find
            fields(obj: list) - list of flat_fields_static with info from form
            u_code - user or system codename
        return:
            multiple_choice id: int - id of choice in destination task
            field destination id: int - id of field in destination task

    """
    if isinstance(fields, list):
        for field in fields:
            if field.info and field.info.code == u_code:
                for option_choice in field.info.options:
                    if option_choice.choice_value == name:
                        return option_choice.choice_id, field.id
        return None, None
    else:
        raise Exception('Fields must be a list')


def find_choice_name_by_choice_id(choice_id, fields, u_code):
    if isinstance(fields, list):
        for field in fields:
            if field.info and field.info.code == u_code:
                for option_choice in field.info.options:
                    if option_choice.choice_id == choice_id:
                        return option_choice.choice_value


def get_id_by_code(form_field: list, u_code: str) -> int:
    """
        args: form_field - list of form fields, u_code - identifier field which need find
        return: field id
    """
    field_id = None
    for field in form_field:
        if field.info and field.info.code == u_code:
            field_id = field.id
    return field_id


def get_value(obj):
    if obj is None:
        return None
    elif obj.type == 'multiple_choice':
        if obj.value and len(obj.value.choice_names) == 1:
            value = obj.value.choice_names[0]
        else:
            value = obj.value
    else:
        value = obj.value
    return value


def get_exception():
    exc_type, exc_obj, tb = sys.exc_info()
    while True:
        if tb.tb_next is None:
            break
        tb = tb.tb_next
    f = tb.tb_frame
    line_no = tb.tb_lineno
    filename = f.f_code.co_filename
    linecache.checkcache(filename)
    line = linecache.getline(filename, line_no, f.f_globals)
    return f'EXCEPTION IN {filename}, LINE {line_no} "{line.strip()}"): {exc_obj}'


class Fields:
    """
    Stores needed fields from form as class attributes
    Used in conjunction with get_fields_by_name() to get simple structure keeping fields from the task
    Attributes are created during initialization in two forms:
        class_variable.field_name - stores value
        class_variable._field_name - stores copy of the Field
    """

    def __init__(self, **kwargs):
        self.__dict__ = {k: extract_value(v) for k, v in kwargs.items()}
        self.__dict__.update({f'_{k}': v for k, v in kwargs.items()})

    def __str__(self):
        return create_object_str(self) + "\n"


def extract_value(v):
    """Extract right value from given input."""
    return (
        None if (v is None or v.value is None) else
        v.value.choice_names[0] if v.type == 'multiple_choice' else
        v.value.first_name + ' ' + v.value.last_name if v.type == 'person' else
        v.value.values if v.type == 'catalog' else
        v.value)


def create_object_str(self, *args, skip=None):
    """
    Creates object description string

    :param self: object to process
    :param args: filter for keys, if empty - adds everything
    :param skip: list of keys to skip (used for not printing nested fields option)
    :return: object description [ClassName: attr1 = value, attr2 = value, ...]
    """
    return '[{}: {}]'.format(self.__class__.__name__, gather_attrs(self, *args, skip=skip))


def get_fields_by_name(fields_list, **kwargs):
    """ Uses get_fields with object_by_name"""
    return get_fields(fields_list, object_by_name, **kwargs)


def get_fields_by_code(fields_list, **kwargs):
    """ Uses get_fields with object_by_name"""
    return get_fields(fields_list, object_by_code, **kwargs)


def get_fields(fields_list, object_function, **kwargs):
    """
    Returns fields from the form task and attaches them as attributes to the field list structure
    Usage: first, create dictionary with attribute names as keys and field name as values, for example:

    Code example:
        f_dict = {"mode": "Working mode", "copy_source": "Number of a parent form"}
        fields = get_fields_by_name(self.task.flat_fields, **f_dict)

    Than you can use
        fields.mode (stores values of "Working mode" field)
        fields._mode (stores original "Working mode" field as pyrus-api structure)

    :param object_function: function to use (object_by_id or object_by_name)
    :param fields_list: list of fields (usually task.flat_fields)
    :param kwargs: dictionary, <key> = attribute name, <value> = field name
    :return: variable, which attributes set to the field values
    """

    return Fields(**{k: object_function(fields_list, v) for k, v in kwargs.items()})
