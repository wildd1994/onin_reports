from pyrus.models import requests
from pyrus.models import entities


class NewTaskCommentRequest(requests.TaskCommentRequest):

    def __init__(self, text=None, approval_choice=None, approval_steps=None, action=None,
                 attachments=None, field_updates=None, approvals_added=None,
                 participants_added=None, reassign_to=None, due=None, due_date=None,
                 duration=None, scheduled_date=None, scheduled_datetime_utc=None,
                 cancel_schedule=None, added_list_ids=None, removed_list_ids=None,
                 approvals_removed=None, approvals_rerequested=None, subject=None,
                 participants_removed=None, channel=None, subscribers_added=None,
                 cancel_schedule_custom=None, subscribers_removed=None):
        super().__init__(text, approval_choice, approval_steps, action, attachments, field_updates, approvals_added,
                         participants_added, reassign_to, due, due_date, duration, scheduled_date,
                         scheduled_datetime_utc, cancel_schedule, added_list_ids, removed_list_ids, approvals_removed,
                         approvals_rerequested, subject, participants_removed)
        if subscribers_removed:
            if not isinstance(subscribers_removed, list):
                raise TypeError('subscribers_removed must be a list')
            self.subscribers_removed = []
            for person in subscribers_removed:
                if isinstance(person, entities.Person):
                    self.subscribers_removed.append(person)
                elif isinstance(person, int):
                    self.subscribers_removed.append(entities.Person(id=person))
                else:
                    self.subscribers_removed.append(entities.Person(email=person))
        if subscribers_added:
            if not isinstance(subscribers_added, list):
                raise TypeError('subscribers_added must be a list')
            self.subscribers_added = []
            for person in subscribers_added:
                if isinstance(person, entities.Person):
                    self.subscribers_added.append(person)
                elif isinstance(person, int):
                    self.subscribers_added.append(entities.Person(id=person))
                else:
                    self.subscribers_added.append(entities.Person(email=person))
        if text:
            self.formatted_text = text
            if isinstance(self.formatted_text, str):
                self.formatted_text = self.formatted_text.replace('\n', '<br>')
            delattr(self, 'text')
        if cancel_schedule_custom:
            if isinstance(cancel_schedule_custom, bool):
                self.cancel_schedule = cancel_schedule_custom
        if channel:
            if not isinstance(channel, str):
                raise TypeError('channel must be an instance of str')
            if channel not in ['email', 'telegram', 'facebook', 'vk', 'viber', 'instagram', 'private_channel',
                               'whats_app', 'mobile_app', 'web_widget', 'sms', 'custom']:
                raise TypeError('channel must be correct')
            self.channel = entities.Channel(type=channel)
